/* -*- mode: c; c-basic-offset: 2; indent-tabs-mode: nil; -*-
 * Copyright (C) 2013, 2016 Henner Zeller <h.zeller@acm.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http: *gnu.org/licenses/gpl-2.0.txt>
 */

/*
 * We do this in plain C so that we can use designated initializers.
 */
#include "hardware-mapping.h"

#define GPIO_BIT(b) (1<<(b))

struct HardwareMapping matrix_hardware_mappings[] = {
  /*
   * The regular hardware mapping described in the wiring.md and used
   * by the adapter PCBs.
   */
  {
    .name          = "regular",

    .output_enable = GPIO_BIT(0),
    .clock         = GPIO_BIT(1),
    .strobe        = GPIO_BIT(2),

    /* Address lines */
    .a             = GPIO_BIT(3),
    .b             = GPIO_BIT(4),
    .c             = GPIO_BIT(5),

    /* Parallel chain 0, RGB for both sub-panels */
    .p0_r1         = GPIO_BIT(6),
    .p0_g1         = GPIO_BIT(7),
    .p0_b1         = GPIO_BIT(8),
    .p0_r2         = GPIO_BIT(9),
    .p0_g2         = GPIO_BIT(10),
    .p0_b2         = GPIO_BIT(11),

    /* All the following are only available with 40 GPIP pins, on A+/B+/Pi2,3 */
    /* Chain 1 */
    .p1_r1         = GPIO_BIT(12),
    .p1_g1         = GPIO_BIT(13),
    .p1_b1         = GPIO_BIT(14),
    .p1_r2         = GPIO_BIT(15),
    .p1_g2         = GPIO_BIT(16),
    .p1_b2         = GPIO_BIT(17),

    /* Chain 2 */
    .p2_r1         = GPIO_BIT(18),
    .p2_g1         = GPIO_BIT(19),
    .p2_b1         = GPIO_BIT(20),
    .p2_r2         = GPIO_BIT(21),
    .p2_g2         = GPIO_BIT(22),
    .p2_b2         = GPIO_BIT(23),

    /* Chain 3 */
    .p3_r1         = GPIO_BIT(24),
    .p3_g1         = GPIO_BIT(25),
    .p3_b1         = GPIO_BIT(26),
    .p3_r2         = GPIO_BIT(27),
    .p3_g2         = GPIO_BIT(28),
    .p3_b2         = GPIO_BIT(29),


  },

  {0}
};
