/*
 * NOTE:
 *
 * Transformers are deprecated. For the kind of mappings they were be
 * used by they turned out to be too complicated.
 *
 * They have been superseeded by the simpler PixelMapper, see pixel-mapper.h
 */
#include "deprecated-transformer.h"
